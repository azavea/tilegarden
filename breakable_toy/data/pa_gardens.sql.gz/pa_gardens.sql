--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.8
-- Dumped by pg_dump version 9.6.8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: pa_gardens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pa_gardens (
    gid integer NOT NULL,
    name character varying,
    organization character varying,
    city character varying,
    state character varying,
    country character varying,
    lat numeric,
    lon numeric,
    geom public.geometry,
    CONSTRAINT enforce_dims_geom CHECK ((public.st_ndims(geom) = 2)),
    CONSTRAINT enforce_geotype_geom CHECK (((public.geometrytype(geom) = 'POINT'::text) OR (geom IS NULL))),
    CONSTRAINT enforce_srid_geom CHECK ((public.st_srid(geom) = 4326))
);


ALTER TABLE public.pa_gardens OWNER TO postgres;

--
-- Name: pa_gardens_gid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pa_gardens_gid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pa_gardens_gid_seq OWNER TO postgres;

--
-- Name: pa_gardens_gid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pa_gardens_gid_seq OWNED BY public.pa_gardens.gid;


--
-- Name: pa_gardens gid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pa_gardens ALTER COLUMN gid SET DEFAULT nextval('public.pa_gardens_gid_seq'::regclass);


--
-- Data for Name: pa_gardens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pa_gardens (gid, name, organization, city, state, country, lat, lon, geom) FROM stdin;
1	Ambler Arboretum	Temple University	Ambler	PA	US	40.1651449	-75.193341	0101000020E610000076FEEDB25FCC52C0F44CD47723154440
2	American College Arboretum	The American College	Bryn Mawr	PA	US	40.018215	-75.326945	0101000020E6100000CEA5B8AAECD452C0F8A57EDE54024440
3	Appleford/Parsons-Banks Arboretum	\N	Villanova	PA	US	40.0513553	-75.3225689	0101000020E61000003A0D07F8A4D452C0F6FC7ACF92064440
4	Arboretum at Penn State	Pennsylvania State University	State College	PA	US	40.8060705	-77.8684812	0101000020E610000037CC2B32957753C09BE271512D674440
5	Arboretum at the Reading Public Museum	Reading Public Museum	Reading	PA	US	40.3277255	-75.95539579999999	0101000020E610000016EF6C3425FD52C05A48C0E8F2294440
6	Arboretum at Penn State Behrend	Penn State Erie, The Behrend College	Erie	PA	US	42.119308	-79.98371399999999	0101000020E610000082A7902BF5FE53C059130B7C450F4540
7	Arboretum of the Barnes Foundation	Barnes Foundation	Merion	PA	US	39.9979437	-75.2405778	0101000020E610000031C96DA065CF52C0E75F819EBCFF4340
8	Arboretum Villanova	Villanova University	Villanova	PA	US	40.037056	-75.34358	0101000020E6100000D2E3F736FDD552C06F0F4240BE044440
9	Awbury Arboretum	\N	Philadelphia (East Germantown)	PA	US	40.0505747	-75.16805889999999	0101000020E61000004FD31D7AC1CA52C0A440553B79064440
10	Bartram's Garden	\N	Philadelphia (Fairmount Park)	PA	US	39.9881142	-75.1971204	0101000020E6100000F7D7E19E9DCC52C04ADBAE867AFE4340
11	Bowman's Hill Wildflower Preserve	\N	New Hope	PA	US	40.331366	-74.93919799999999	0101000020E6100000FD9DEDD11BBC52C0D0807A336A2A4440
12	Brandywine Wildflower and Native Plant Gardens	Brandywine River Museum	Chadds Ford	PA	US	39.870009	-75.593158	0101000020E610000017D7F84CF6E552C0E31C75745CEF4340
13	Bryn Mawr Campus Arboretum	Bryn Mawr College	Bryn Mawr	PA	US	40.0281065	-75.3152341	0101000020E61000006085A5CB2CD452C00B2769FE98034440
14	Centennial Arboretum	\N	Philadelphia (Fairmount Park)	PA	US	39.9830151	-75.2138397	0101000020E61000008885B58CAFCD52C0B2FC5470D3FD4340
15	Chanticleer Garden	\N	Wayne	PA	US	40.031311	-75.391362	0101000020E61000006BB933130CD952C0A680B4FF01044440
16	Chatham University Arboretum	Chatham University	Pittsburgh	PA	US	40.4482193	-79.9242625	0101000020E6100000D49AE61D27FB53C0CF7701405F394440
17	Crozer Arboretum	\N	Upland	PA	US	39.8559457	-75.37074679999999	0101000020E61000002F46C950BAD752C06F53F2A08FED4340
18	William F. Curtis Arboretum	Cedar Crest College	Allentown	PA	US	40.0860151	-75.1494304	0101000020E6100000CE41864490C952C028BBF48A020B4440
19	Curtis Hall Arboretum	\N	Wyncote	PA	US	40.0860151	-75.1494304	0101000020E6100000CE41864490C952C028BBF48A020B4440
20	Lee and Virginia Graver Arboretum	Muhlenberg College	Bath	PA	US	40.80005999999999	-75.3632049	0101000020E6100000CECFC3BF3ED752C03A6BB75D68664440
21	Haverford College Arboretum	Haverford College	Haverford	PA	US	40.0093478	-75.305656	0101000020E6100000E0F42EDE8FD352C010A5074F32014440
22	Henry Foundation for Botanical Research	\N	Gladwyne	PA	US	40.0533403	-75.28656	0101000020E6100000DF15C1FF56D252C08807DEDAD3064440
23	Hershey Gardens	M.S. Hershey Foundation	Hershey	PA	US	40.2851342	-76.65205619999999	0101000020E6100000DB89ED49BB2953C04EFC07477F244440
24	Holtwood Arboretum	\N	Holtwood	PA	US	39.8320468	-76.3274593	0101000020E61000005911DA17F51453C0E85E718280EA4340
25	The Horticulture Center	\N	Philadelphia (Fairmount Park)	PA	US	39.9834	-75.21020159999999	0101000020E6100000476469F173CD52C076711B0DE0FD4340
26	Jenkins Arboretum	\N	Devon	PA	US	40.060254	-75.4350079	0101000020E61000001B00602BD7DB52C002BA2F67B6074440
27	Lake Erie Arboretum	\N	Erie	PA	US	42.1168782	-80.117689	0101000020E610000055867137880754C0C44E67DDF50E4540
28	Liberty Forge Arboretum	\N	Mechanicsburg	PA	US	40.1749905	-76.9266787	0101000020E610000096992DB44E3B53C02B4EB51666164440
29	Longwood Gardens	\N	Kennett Square	PA	US	39.871271	-75.67472029999999	0101000020E6100000A09C0D9E2EEB52C0037AE1CE85EF4340
30	Marywood University Arboretum	Marywood University	Scranton	PA	US	41.433412	-75.63725350000001	0101000020E6100000BE70E7C2C8E852C0D3D85E0B7AB74440
31	Merion Botanical Park	\N	Merion	PA	US	39.9948969	-75.25074719999999	0101000020E610000011E4FB3D0CD052C0263218C858FF4340
32	Mont Alto Arboretum	Penn State Mont Alto	Mont Alto	PA	US	39.8406628	-77.54259859999999	0101000020E6100000BE767AEFB96253C05D7BB0D69AEB4340
33	Morris Arboretum	University of Pennsylvania	Philadelphia	PA	US	40.0881683	-75.22210129999999	0101000020E61000008AF95EE836CE52C09F854E19490B4440
34	National Aviary	\N	Pittsburgh	PA	US	40.45325070000001	-80.00995859999999	0101000020E610000017546529A30054C0D0B1721E043A4440
35	Phipps Conservatory & Botanical Gardens	\N	Pittsburgh	PA	US	40.4396208	-79.9467808	0101000020E6100000C41E7F0E98FC53C018528F7E45384440
36	Pittsburgh Botanic Garden	\N	Pittsburgh	PA	US	40.41711650000001	-80.1701298	0101000020E6100000CDC41968E30A54C09F0FCF1264354440
37	Renziehausen Park Rose Garden and Arboretum	\N	McKeesport	PA	US	40.3398592	-79.8237419	0101000020E61000001336F22FB8F453C0539F9A81802B4440
38	Rodef Shalom Biblical Botanical Garden	Rodef Shalom Temple	Pittsburgh	PA	US	40.4479037	-79.9433675	0101000020E6100000FE26142260FC53C0F2A08FE854394440
39	Henry Schmieder Arboretum	Delaware Valley College	Doylestown	PA	US	40.2982282	-75.15994289999999	0101000020E61000008D2E25813CCA52C05ADF76572C264440
40	Scott Arboretum	Swarthmore College	Swarthmore	PA	US	39.9061422	-75.3523866	0101000020E61000001DA386808DD652C04343B577FCF34340
41	Swiss Pines	\N	Malvern	PA	US	40.0362184	-75.5138118	0101000020E61000002153E34AE2E052C0B9C1F5CDA2044440
42	Louise Arnold Tanger Arboretum	\N	Lancaster	PA	US	40.0378755	-76.3055144	0101000020E6100000411D458C8D1353C0EAE8B81AD9044440
43	Taylor Memorial Arboretum	\N	Wallingford	PA	US	39.8721069	-75.3696375	0101000020E610000003780B24A8D752C0D70EEB32A1EF4340
44	John J. Tyler Arboretum	\N	Media	PA	US	39.9370933	-75.4301055	0101000020E61000001A1538D986DB52C07E665AACF2F74340
45	Welkinweir	\N	Pottstown	PA	US	40.1551755	-75.6816474	0101000020E6100000D2996A1CA0EB52C0FAD170CADC134440
\.


--
-- Name: pa_gardens_gid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pa_gardens_gid_seq', 45, true);


--
-- Name: pa_gardens pa_gardens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pa_gardens
    ADD CONSTRAINT pa_gardens_pkey PRIMARY KEY (gid);


--
-- PostgreSQL database dump complete
--

